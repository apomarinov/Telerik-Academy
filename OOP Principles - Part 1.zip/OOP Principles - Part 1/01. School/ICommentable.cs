﻿using System;

namespace School
{
    interface ICommentable
    {
        string Comment
        {
            get;
            set;
        }
    }
}
